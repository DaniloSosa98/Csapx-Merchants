Basically I couldn't figure out the sys.arg because Im using vscode
instead of pycharm. I searched for ways to edit the .json so I could 
run it from the command line, but they only served for debugging.
I didn't seek help because I thought I could figure it out, but it was
to late when I realize I couldn't. I apologize for this because I
imagine it will be harder and more annoying to grade it by inserting 
the method you wish to try. I left the default .txt document to 1M.